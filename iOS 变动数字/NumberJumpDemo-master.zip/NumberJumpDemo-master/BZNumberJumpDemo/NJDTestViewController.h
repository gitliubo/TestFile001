//
//  NJDTestViewController.h
//  BZNumberJumpDemo
//
//  Created by Bruce on 14-7-1.
//  Copyright (c) 2014年 com.Bruce.Number. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NJDBezierCurve.h"

@interface NJDTestViewController : UIViewController {
    CATextLayer *textLayer;
}

@end
